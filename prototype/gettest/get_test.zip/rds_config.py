#!/usr/bin/python
#config file containing credentials for rds mysql instance
db_username = "master"
db_password = "NFP!2017!"
db_name = "proto"
db_endpoint = "jdg-proto-type.ccf0v3myj6k1.us-west-2.rds.amazonaws.com"
